from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy

app = Flask(__name__)

# CREATE DATABASE
app.config['SQLALCHEMY_DATABASE_URI'] = "sqlite:///books.db"
# Optional: But it will silence the deprecation warning in the console.
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
db = SQLAlchemy(app)


# CREATE TABLE
class Book(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(250), unique=True, nullable=False)
    author = db.Column(db.String(250), nullable=False)
    start_date = db.Column(db.Integer, nullable=False)
    finish_date = db.Column(db.Integer, nullable=False)
    rating = db.Column(db.Float, nullable=False)

    # 옵션: 각각의 book객체가 출력될 때 제목으로 구별될 수 있게함
    def __repr__(self):
        return f'<Book {self.title}>'


db.create_all()

# # CREATE RECORD
# new_book = Book(id=1, title="HarryPotter", author='J.K.Rowling', rating=9.3)
# db.session.add(new_book)
# db.session.commit()

# 나의 도서관 home


@app.route('/')
def library_home():
    # READ ALL RECORDS
    all_books = db.session.query(Book).all()
    return render_template("library.html", books=all_books)

# 도서관에 목록 추가하기


@app.route("/add", methods=['POST', 'GET'])
def add():
    if request.method == "POST":
        # CREATE RECORD
        new_book = Book(
            title=request.form["title"],
            author=request.form["author"],
            start_date=request.form["start_date"],
            finish_date=request.form['finish_date'],
            rating=request.form["rating"]
        )
        db.session.add(new_book)
        db.session.commit()
        return redirect(url_for('library_home'))
    return render_template("libadd.html")

# 별점 수정하기


@app.route("/edit", methods=["GET", "POST"])
def edit():
    if request.method == "POST":
        # UPDATE RECORD
        book_id = request.form["id"]
        book_to_update = Book.query.get(book_id)
        book_to_update.rating = request.form["rating"]
        db.session.commit()
        return redirect(url_for('library_home'))
    book_id = request.args.get('id')
    book_selected = Book.query.get(book_id)
    return render_template("edit_rating.html", book=book_selected)

# 도서관 목록 삭제하기


@app.route("/delete")
def delete():
    book_id = request.args.get('id')

    # DELETE A RECORD BY ID
    book_to_delete = Book.query.get(book_id)
    db.session.delete(book_to_delete)
    db.session.commit()
    return redirect(url_for('library_home'))


if __name__ == "__main__":
    app.run(debug=True)


# library.html
# libadd.html
# edit_rating.html
